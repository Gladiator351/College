import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Man here.
 * 
 * @author Zhiguang Xu
 * @version 1.0
 */
public class Man  extends Actor
{
    /**
     * Act - do whatever the Man wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        checkKeypress();
        if (canSee(Wall.class)){
            setImage("man1.png");
        }
        if (canSee(Fire.class)){
            Greenfoot.playSound("au.wav");
            setImage("man2.png");
        }
        if (canSee(Door.class)){
            Greenfoot.playSound("hooray.wav");
            Greenfoot.stop();
        }
    }    

    /**
     * Check whether a control key on the keyboard has been pressed.
     * If it has, react accordingly.
     */
    public void checkKeypress()
    {
        if (Greenfoot.isKeyDown("left")) 
        {
            setLocation(getX()-1,getY());
        }
        if (Greenfoot.isKeyDown("right")) 
        {
            setLocation(getX()+1,getY());
        }
        if (Greenfoot.isKeyDown("up")) 
        {
            setLocation(getX(),getY()-1);
        }
        if (Greenfoot.isKeyDown("down")) 
        {
            setLocation(getX(),getY()+1);
        }
    }

    public boolean canSee(Class clss)
    {
        Actor actor = getOneObjectAtOffset(0, 0, clss);
        return actor != null;        
    }

}
