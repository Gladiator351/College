import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
import java.io.*;

/**
 * Write a description of class Museum here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Museum  extends World
{
    static int WIDTH = 15;
    static int HEIGHT = 15;
    /**
     * Constructor for objects of class Museum.
     * 
     */
    public Museum()
    {    
        // Create a new world with 15x15 cells with a cell size of 50x50 pixels.
        super(WIDTH, HEIGHT, 50);
        populate("museum.txt");
    }
    
    /**
     * 
     */
    public void populate(String file){
        // removeObjects(getObjects(null));
        try{
            Scanner sc = new Scanner(new File(file));
    
            int i = 0;
            while(sc.hasNext()){
                String s = sc.next();
                for(int j = 0; j < WIDTH; j++){
                    switch(s.charAt(j)){
                        case '0': addObject(new Fire(), j, i);
                                  break;
                        case '1': addObject(new Wall(), j, i);
                                  break;
                        case '2': addObject(new Door(), j, i);
                                  break;
                   }
                }
                i++;
            }
        }
        catch(Exception e){
        }
        addObject(new Man(), WIDTH -1, HEIGHT -1);
        addObject(new Door(), 0, 0);

    }
}
